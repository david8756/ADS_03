/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.cajero;

/**
 *
 * @author SENA
 */
public class Cajero {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
