package com.mycompany.banco;

import java.util.Random;
import javax.swing.JOptionPane;

public class Cajero {

    private int saldo = 7000000, saldoc = 20000000, retiroD = 2100000;
    private boolean continuar = true;

    public Cajero() {
    }

    public int getSaldo() {
        return saldo;
    }

    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }

    public int getSaldoc() {
        return saldoc;
    }

    public void setSaldoc(int saldoc) {
        this.saldoc = saldoc;
    }

    public int getRetiroD() {
        return retiroD;
    }

    public void setRetiroD(int retiroD) {
        this.retiroD = retiroD;
    }

    public void cajero_automatico() {
        while (continuar) {

            try {
                StringBuilder menu = new StringBuilder("MENU CAJERO AUTOMATICO\n\n");
                menu.append("Seleccione una opcion del 1 al 4 asi: \n")
                        .append("1. Consultar saldo \n")
                        .append("2. Consignar dinero\n")
                        .append("3. Retirar dinero \n")
                        .append("4. Salir");
                String opcion = JOptionPane.showInputDialog(null, menu, "Cajero Automatico", JOptionPane.QUESTION_MESSAGE);
                if (opcion == null) {
                    if (confirmaesalida()) {
                        continuar = false;
                    }
                    continue;
                }
                int opc = Integer.parseInt(opcion);
                switch (opc) {
                    case 1:
                        consultaSaldo();
                        break;
                    case 2:
                        consignarDinero();

                        break;
                    default:
                }

            } catch (NumberFormatException e) {

                JOptionPane.showInputDialog(null, "Error", "Ingrese un numero del 1 al 4", JOptionPane.QUESTION_MESSAGE);
            }
        }
    }

    public boolean confirmaesalida() {
        int confirmar = JOptionPane.showConfirmDialog(null, "¿Esta seguro que desea salir?", "Confirmar salida", JOptionPane.YES_NO_OPTION);

        return confirmar == JOptionPane.YES_OPTION;
    }

    public String idValidacion() {
        Random random = new Random();
        int numero = random.nextInt(9000) + 1000;
        return "ID #" + numero + "\n";

    }

    public void consultaSaldo() {
        String validacion = idValidacion();
        StringBuilder mensaje = new StringBuilder("Consultar Saldo \n");
        mensaje.append(validacion)
                .append("Saldo actual: $")
                .append(String.format("%,d,", saldo));
        JOptionPane.showMessageDialog(null, mensaje, " Consultar saldo", JOptionPane.INFORMATION_MESSAGE);

    }

    public void consignarDinero() {
        try {
            String consignacion = idValidacion();
            StringBuilder mensaje2 = new StringBuilder("Consultar saldo \n");
            mensaje2.append(consignacion)
                    .append("Saldo total")
                    .append(String.format("%,d", saldo));
            JOptionPane.showInputDialog(null,"No ingresar monedas","Advertencia", JOptionPane.WARNING_MESSAGE);
            String con = JOptionPane.showInputDialog(null,"Ingrese valor a consignar",JOptionPane.DEFAULT_OPTION);
            if(con == null){
                return;
            }
            int valor = Integer.parseInt(con);
            
            if(valor % 10000 != 0){
            JOptionPane.showConfirmDialog(null,"Error, solo multiplos de 10000");
            return;
        }
            saldo = valor + saldo;
            JOptionPane.showMessageDialog(null,"Su saldo actual es",JOptionPane.INFORMATION_MESSAGE);
            JOptionPane.showMessageDialog(null,"Su saldo actual es", con, saldo);
        }
        

    }

}
