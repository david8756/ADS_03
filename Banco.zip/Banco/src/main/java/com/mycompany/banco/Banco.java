/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.banco;

/**
 *
 * @author SENA
 */
public class Banco {

    public static void main(String[] args) {
        Cajero cajero = new Cajero();
        cajero.cajero_automatico();
       
    }
}
